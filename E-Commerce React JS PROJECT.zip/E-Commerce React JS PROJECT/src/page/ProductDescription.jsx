import { useParams } from "react-router-dom";
import { Mydata } from "./DataProvider";
import { useContext } from "react";

const ProductDescription = () => {
  let { id } = useParams();
  let { product } = useContext(Mydata);
  let myData = product.filter((itm) => itm.productId == id);
  console.log(myData);
  return <div>A product description is a salesperson that works 24/7, 365 days a year. Product descriptions convince the customer to buy (or not to buy) your product. If you can’t get it right, your customer will leave and never return. 
   <br></br><br></br>

  Some sellers may not realize the full extent of the product description’s potential. When prospective customers scroll through dozens of pages, looking for that perfect product to buy, your product description must stand out from the rest. </div>;
};

export default ProductDescription;
