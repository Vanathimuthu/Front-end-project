import  { useContext, useEffect, useState } from "react";
import { Mydata } from "./DataProvider";
// import Products from './Products'
import PropTypes from 'prop-types';

const ProductEditCreate = ({ create, edit, editID }) => {
  let { setProduct, product } = useContext(Mydata);
  let [newItem, setNewItem] = useState({
    productName: "",
    price: "",
    productDescription: "",
    productImage: "",
    isAdded: false,
    cartCount: 0,
  });

  useEffect(() => {
    console.log(editID);
    let editItem = product.filter((itm) => itm.productId == editID);
    console.log(editItem);
    if(editItem.length>0){
    setNewItem(editItem[0]);
  }
},[editID,edit,product ]);


  function mangeChange(eve) {
    setNewItem((preVal) => ({
      ...preVal,
      [eve.target.id]: eve.target.value,
    }));
  }

  function manageSubmit() {
    console.log(newItem);

    if (edit) {
      let notEditProducts = product.filter((itm) => itm.productId !== editID);
      setProduct([...notEditProducts, newItem]);
    } else {
      setNewItem((preVal) => ({ ...preVal, id: product.length + 1 }));
      setProduct((preVal) => [...preVal, newItem]);
    }
  }

  return (
    <div>
      {create && (
        <div>
          <input
            type="text"
            id="productName"
            placeholder="productName"
            value={newItem.productName}
            onChange={mangeChange}
          />
          <input
            type="text"
            id="price"
            placeholder="price"
            value={newItem.price}
            onChange={mangeChange}
          />
          <input
            type="text"
            id="productDescription"
            placeholder="productDescription"
            value={newItem.productDescription}
            onChange={mangeChange}
          />
          <input
            type="file"
            id="productImage"
            placeholder="productImage"
            value={newItem.productImage}
            onChange={mangeChange}
          />
        </div>
      )}

      {edit && (
        <h1>
          {" "}
          <div>
            <input
              type="text"
              id="productName"
              placeholder="productName"
              value={newItem.productName}
              onChange={mangeChange}
            />
            <input
              type="text"
              id="price"
              placeholder="price"
              value={newItem.price}
              onChange={mangeChange}
            />
            <input
              type="text"
              id="productDescription"
              placeholder="productDescription"
              value={newItem.productDescription}
              onChange={mangeChange}
            />
            <input
              type="file"
              id="productImage"
              placeholder="productImage"
              value={newItem.productImage}
              onChange={mangeChange}
            />
          </div>
        </h1>
      )}
      <button onClick={manageSubmit}>Submit</button>
    </div>
  );
};
ProductEditCreate.propTypes = { create: PropTypes.bool, edit: PropTypes.bool, editID: PropTypes.number}

export default ProductEditCreate;