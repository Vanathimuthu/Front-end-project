import {createContext, useState} from 'react';
import PropTypes from 'prop-types';

export let Mydata=createContext({});


const DataProvider=({ children })=>{
    let products=[{
        productid:1,
        productname:'Iphone15 pro',
        productprice:150000,
        productinfo:'wireless mobile',
        productimg:'https://th.bing.com/th?id=OPAC.cK9o8VQRiDXBbw474C474&w=220&h=210&c=17&o=5&dpr=1.3&pid=21.1',
        isAdded:false,
        cartCount:0
    },
 
    {
        productid:2,
        productname:'Iphone16+',
        productprice:150000,
        productinfo:'wireless mobile',
        productimg:'https://media.croma.com/image/upload/v1664009258/Croma%20Assets/Communication/Mobiles/Images/243459_0_ljp1lm.png',
        isAdded:false,
        cartCount:0
    }
,{
    productid:3,
    productname:'Samsung S24 Ultra',
    productprice:150000,
    productinfo:'wireless mobile',
    productimg:'https://pisces.bbystatic.com/image2/BestBuy_US/images/products/6570/6570355_sd.jpg',
    isAdded:false,
        cartCount:0
}];
let [registereduser,setRegistereduser]=useState([])
let [product,setProduct]=useState(products)
let [loginuser,setLoginuser]=useState({})
let [cartItems, setCartItems] = useState([]);
const logoutUser = () => { setLoginuser({})}
    return(
        <Mydata.Provider
         value={{
            name:"vanu",product,setProduct,
            registereduser,setRegistereduser,
            loginuser,setLoginuser,logoutUser,
            cartItems, setCartItems,
        }}>{ children }</Mydata.Provider>
    )
}
DataProvider.propTypes=
{
    children:PropTypes.node.isRequired
}
export default DataProvider;