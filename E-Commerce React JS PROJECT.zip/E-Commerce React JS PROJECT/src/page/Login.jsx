import { useState, useContext,useEffect} from "react"
import { Mydata } from "./DataProvider";
import { useNavigate } from "react-router-dom";
import { useSearchParams } from "react-router-dom";
const Login = () => {
let [searchParams]=useSearchParams();

  let navigate = useNavigate();
  //let { loginuser, setLoginuser } = useContext(Mydata);
  let { registereduser, loginuser,setLoginuser } = useContext(Mydata);
  let [loginfo, setLoginfo] = useState({ 
    username: "", 
    password: "",
    role:"users" });

    useEffect(() => { const usernameParam = searchParams.get("username"); 
      const roleParam = searchParams.get("role");
       if (usernameParam) { setLoginfo((prev) =>
         ({ ...prev, username: usernameParam })); } 
       if (roleParam) { setLoginfo((prev) => 
        ({ ...prev, role: roleParam }));
      } }, [searchParams]);

  function logindet(e) {
    setLoginfo((preVal) => ({ ...preVal,
      [e.target.id]:e.target.value }));
  }

  async function loginbtn() {
    
    let logged = registereduser.find(
      (itm) => itm.username === loginfo.username &&  loginfo.password
    );
    if (logged) {
      setLoginuser(loginfo);
      console.log(loginuser)
      navigate("/products");
    } else {
      alert("Invalid credentials");
    }
  }

  return (
    <div>
      <form onSubmit={loginbtn}>
        <input
          type="text"
          id="username"
          value={loginfo.username}
          onChange={logindet}
          placeholder="Username"
        />
        <input
          type="password"
          id="password"
          value={loginfo.password}
          onChange={logindet}
          placeholder="Password"
        />
        <select name="" id="role" onChange={logindet} value={loginfo.role}>
          <option value="users">Users</option>
          <option value="admin">Admin</option>
        </select>
        <button type="submit" onClick={loginbtn}>Login</button>
      </form>
    </div>
  );
};

export default Login;

