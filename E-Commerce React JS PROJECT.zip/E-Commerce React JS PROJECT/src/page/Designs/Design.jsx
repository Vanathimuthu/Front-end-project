// import react from 'react';
import Header from './layout/Header';
import Footer from './layout/Footer';
import {Outlet} from 'react-router-dom';
import Menubar  from './layout/Menubar';

const Design=()=>{
    return(
        <>
        <header><Header/></header>
        <section className='main-content'>
        <nav>
           <Menubar/>
        </nav>
        <menu><Outlet/></menu>
        </section>
        <footer><Footer/></footer>
        </>
    )
}
export default Design;