import { useContext, useState } from "react";
import { Mydata } from "../../../DataProvider";

const Userprofile = () => {
  let { registereduser } = useContext(Mydata);
  const [profilePic, setProfilePic] = useState("https://static.vecteezy.com/system/resources/previews/002/318/271/original/user-profile-icon-free-vector.jpg");

  const handleProfilePicChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfilePic(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div>
      <h1>Profile Page</h1>
      <div className="profile-page">
        <img
          className="profile-pic"
          src={profilePic}
          alt="Profile"
        />
        <input type="file" className="profile-pic-input" onChange={handleProfilePicChange} />
        <h2>User Information</h2>
        <div>
          {registereduser.map((itm, ind) => (
            <div key={ind} className="user-info">
              <h3 className="user-id">ID: {ind}</h3>
              <h3 className="user-name">Username: {itm.username}</h3>
            </div>
          ))}
        </div>
        <p>Welcome to your profile.</p>
      </div>
    </div>
  );
};

export default Userprofile;


