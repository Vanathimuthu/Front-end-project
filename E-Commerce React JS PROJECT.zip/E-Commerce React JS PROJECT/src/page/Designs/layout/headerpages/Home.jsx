

const Home = () => {
  
    return (
      <div>
        <div className="logo"></div>
        {/* <h1>
            {registereduser.map((itm, ind) => (
            <h3 className="table-user" key={ind}>
              <h3 className="table-user">{ind}</h3>
              <h3 className="table-user">{itm.username}</h3></h3>))}
       </h1> */}
        <p>Welcome to the home page.</p>
      </div>
    );
  }
  
  export default Home;
  
