import  { useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mydata } from '../../../DataProvider';

const Logout = () => {
  let { logoutUser } = useContext(Mydata);
  let navigate = useNavigate();

  useEffect(() => {
    logoutUser();
    navigate('/login');
  }, [logoutUser, navigate]);

  return (
    <div>
      <h1>Logout Successfully</h1>
    </div>
  );
}

export default Logout;

