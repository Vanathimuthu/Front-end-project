

const Brand = () => {
  return (
    <div>
      <h1>Brand Page</h1>
      <p>Welcome to the brand page.</p>
    </div>
  );
}

export default Brand;
