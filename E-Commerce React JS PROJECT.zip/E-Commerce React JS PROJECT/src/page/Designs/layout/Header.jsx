import { useNavigate } from 'react-router-dom';

const Header = () => {
  let navigate = useNavigate();

  const handleLogoClick = () => {
    navigate('/Home');
  };

  const handleBrandClick = () => {
    navigate('/Brandname');
  };

  const handleProfileClick = () => {
    navigate('/Userprofile');
  };

  const handleLogoutClick = () => {
    
    navigate('/logout');
  };

  return (
    <>
      <div onClick={handleLogoClick} style={{ cursor: 'pointer' }}>Logo</div>
      <div onClick={handleBrandClick} style={{ cursor: 'pointer' }}>Brand Name</div>
      <div onClick={handleProfileClick} style={{ cursor: 'pointer' }}>User Profile</div>
      <div onClick={handleLogoutClick} style={{ cursor: 'pointer' }}>Log Out</div>
    </>
  );
};

export default Header;
