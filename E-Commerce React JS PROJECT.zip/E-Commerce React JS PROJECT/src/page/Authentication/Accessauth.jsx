import { useContext } from "react";
import{Mydata} from '../DataProvider';
import { Outlet } from "react-router-dom";
import PropTypes from "prop-types";
const Accessauth=({ allowedaccess })=>
    {
      let{loginuser}=useContext(Mydata);
 let allowance=allowedaccess.includes(loginuser.role)
return (
   allowance?<Outlet/>:<h2 className="user-restrict">Do not allow the access <br />
      Admin only access the user details <br></br>
      PLEASE LOGIN via ADMIN <br /><img  className="restrict-img" src="https://i.gifer.com/origin/a2/a2dbb9f31a074a7bab6eec9a3f33fe17_w200.gif"></img></h2>
    
);

}
Accessauth.propTypes = 
{ allowedaccess: PropTypes.arrayOf(PropTypes.string).isRequired, };
export  default Accessauth;