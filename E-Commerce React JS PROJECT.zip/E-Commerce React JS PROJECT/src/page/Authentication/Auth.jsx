import { useContext } from "react";
import { Mydata } from "../DataProvider";
import { Outlet } from "react-router-dom";
// import Accessauth from './Accessauth'
import Login from '../Login'
const Auth=()=>{
    let{loginuser}=useContext(Mydata);
    
    return (
        loginuser &&loginuser.username?<Outlet/>:<Login/>
        // <Outlet/>
    );
}
export  default Auth;