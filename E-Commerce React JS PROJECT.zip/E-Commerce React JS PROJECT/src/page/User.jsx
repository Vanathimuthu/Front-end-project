import { useContext, useState } from "react";
import { Mydata } from "./DataProvider";

const Users = () => {
  let { registereduser, setRegistereduser,} = useContext(Mydata);
  let [isEditing, setIsEditing] = useState(false);
  let [currentEditUser, setCurrentEditUser] = useState(null);
  let [newUsername, setNewUsername] = useState('');

  const editUser = (user) => {
    setIsEditing(true);
    setCurrentEditUser(user);
    setNewUsername(user.username);
  };

  const updateUser = () => {
    setRegistereduser((prevUsers) =>
      prevUsers.map((user) =>
        user.username === currentEditUser.username ? { ...user, username: newUsername } : user
      )
    );
    setIsEditing(false);
    setCurrentEditUser(null);
    setNewUsername('');
  };

  const deleteUser = (username) => {
    setRegistereduser((prevUsers) =>
      prevUsers.filter((user) => user.username !== username)
    );
  };

  const cancelEdit = () => {
    setIsEditing(false);
    setCurrentEditUser(null);
    setNewUsername('');
  };
 

  return (
    <div>
      {isEditing && (
        <div>
          <input
            type="text"
            value={newUsername}
            onChange={(e) => setNewUsername(e.target.value)}
          />
          <button onClick={updateUser}>Update</button>
          <button onClick={cancelEdit}>Cancel</button>
        </div>
      )}
      <table className="table-user">
        <thead>
          <tr className="table-user">
            <th className="table-user">ID</th>
            <th className="table-user">Name</th>
            <th className="table-user">Action</th>
          </tr>
        </thead>
        <tbody>
          {registereduser.map((itm, ind) => (
            <tr className="table-user" key={ind}>
              <td className="table-user">{ind}</td>
              <td className="table-user">{itm.username}</td>
              <td className="table-user">
                <button className="user-action" onClick={() => editUser(itm)}>Edit</button><br /><br />
                <button className="user-action" onClick={() => deleteUser(itm.username)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Users;
