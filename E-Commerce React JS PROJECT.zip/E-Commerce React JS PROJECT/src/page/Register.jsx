import { useContext, useState } from "react";
import { Mydata } from './DataProvider.jsx';
import { useNavigate } from "react-router-dom";

const Register = () => {
  const navigate = useNavigate();
  const { registereduser, setRegistereduser } = useContext(Mydata);

  const [registerState, setRegisterState] = useState({
     username: '', password: '' });

  function userpass(eve) {
    setRegisterState((preVal) => ({ ...preVal, [eve.target.id]: eve.target.value }));
  }

  async function reg(e) {
    e.preventDefault();
    console.log(registerState);

    const loginforuser = registereduser.find(
      (itm) => itm.username === registerState.username
    );

    if (loginforuser) {
      alert('Username already exists');
    } 
    else {
      setRegistereduser((preVal) => [...preVal, registerState]);
      alert('Successfully registered');
      navigate("/login");
    }
  }

  return (
    <div>
      <form >
        <label htmlFor="username">Username:
          <input
            type="text"
            name="username"
            id="username"
            value={registerState.username}
            onChange={userpass}
            placeholder="Enter email Id or mobile number"
          />
        </label>
        <label htmlFor="password">Password:
          <input
            type="password"
            name="password"
            id="password"
            value={registerState.password}
            onChange={userpass}
            placeholder="Enter the password"
          />
        </label>
        <button type="submit" onClick={reg}>Register</button>
      </form>
    </div>
  );
};

export default Register;


