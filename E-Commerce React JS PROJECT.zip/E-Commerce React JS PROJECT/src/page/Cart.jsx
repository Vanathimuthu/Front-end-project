
import { useContext } from "react";
import { Mydata } from "./DataProvider";

const Cart = () => {
  let { cartItems } = useContext(Mydata);

 return (
    <div>
      <h1>Cart</h1>
      {cartItems.length === 0 ? (
        <p>No items in cart</p>
      ) : (
        <div className="cart-items">
          {cartItems.map((item, index) => (
            <div key={index} className="cart-item">
              <img src={item.productimg} alt={item.productname} className="cart-item-image" />
              <div className="cart-item-info">
                <p className="cart-item-name">{item.productname}</p>
                <p className="cart-item-price">Rs. {item.productprice}</p>
                <p className="cart-item-quantity">Quantity: {item.cartCount}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Cart;
