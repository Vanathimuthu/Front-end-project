import { useContext, useState } from "react";
import { Mydata } from "./DataProvider";
import { useNavigate } from 'react-router-dom';
import ProducteditCreate from './ProducteditCreate';

const Products = () => {
  let { product, setProduct, cartItems, setCartItems } = useContext(Mydata);
  let navigateUser = useNavigate();
  let [addEdit, setAddEdit] = useState(false);
  let [create, setCreate] = useState(false);
  let [edit, setEdit] = useState(false);
  let [editID, setEditID] = useState(null);

  function addQuantity(eve) {
    let updateProducts = product.map((item) => {
      if (item.productid == eve.target.id) {
        item.cartCount += 1;
      }
      return item;
    });
    setProduct(updateProducts);
  };

  function reduceQuantity(eve) {
    let updateProducts = product.map((item) => {
      if (item.productid == eve.target.id) {
        if (item.cartCount == 1) {
          item.isAdded = false;
          setCartItems(cartItems.filter(cartItem => cartItem.productid !== item.productid));
        }
        item.cartCount -= 1;
      }
      return item;
    });
    setProduct(updateProducts);
  };

  function addProducts(eve) {
    let updateProducts = product.map((item) => {
      if (item.productid == eve.target.id) {
        item.isAdded = true;
        item.cartCount += 1;
      }
      return item;
    });
    setProduct(updateProducts);

    let selecteditem = product.find((item) => item.productid == eve.target.id);
    setCartItems((preVal) => [...preVal, selecteditem]);
    console.log(cartItems);
  }

  function productinfo(eve) {
    navigateUser(`/product/${eve.target.id}`);
  }

  function createproduct() {
    setAddEdit(!addEdit);
    setCreate(!create);
  }

  function editproduct(eve) {
    setAddEdit(!addEdit);
    setEdit(!edit);
    setEditID(eve.target.id);
  }

  function cancellation() {
    setCreate(false);
    setEdit(false);
  }

  return (
    <>
      <button id="create-product" onClick={createproduct}>
        Create
      </button>
      {(create || edit) && (
        <button id="cancel-product" onClick={cancellation} style={{background:'red',color:'white'}}>
          Cancel
        </button>
      )}
      {create && <ProducteditCreate create={create} edit={edit} />}
      {edit && <ProducteditCreate create={create} edit={edit} editId={editID} />}
      <div className="products">
        {product.map((itm, ind) => (
          <div key={ind} className="each-products">
            <div className="product-image-container">
              <img
                className="product-image"
                src={itm.productimg}
                alt={itm.productname}
              />
              <div className="add-product-btn">
                {!itm.isAdded && (
                  <button
                    style={{ backgroundColor:'green', border: "none",color:'white',height:'40px',width:'40px',borderRadius:'10px'}}
                    onClick={addProducts}
                    id={itm.productid}
                  >
                    Add
                  </button>
                )}
                {itm.isAdded && (
                  <div className="added-item">
                    <button
                      className="quantity-btn"
                      style={{ background: "none", border: "none" }}
                      name="add"
                      id={itm.productid}
                      onClick={addQuantity}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        height="24px"
                        viewBox="0 -960 960 960"
                        width="20px"
                        name="add"
                        id={itm.productid}
                        onClick={addQuantity}
                      >
                        <path d="M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z" />
                      </svg>
                    </button>
                    <input value={itm.cartCount} readOnly />
                    <button
                      className="quantity-btn"
                      style={{ background: "none", border: "none" }}
                      name="remove"
                      id={itm.productid}
                      onClick={reduceQuantity}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        height="24px"
                        viewBox="0 -960 960 960"
                        width="20px"
                        name="remove"
                        id={itm.productid}
                        onClick={reduceQuantity}
                      >
                        <path d="M200-440v-80h560v80H200Z" />
                      </svg>
                    </button>
                  </div>
                )}
              </div>
            </div>
            <div className="product-info">
              <p className="product-name">{itm.productname}</p>
              <p className="product-price">Rs. {itm.productprice}</p>
              <p className="product-description">{itm.productinfo}</p>
            </div>
            <button
              id={itm.productid}
              className="product-view"
              onClick={productinfo}
              style={{ backgroundColor:'red', border: "none",color:'white',height:'40px',width:'90px',borderRadius:'10px'}}
            >
              View in detail
            </button>
            <button id={itm.productid} onClick={editproduct}
            style={{ backgroundColor:'Red', border: "none",color:'white',height:'30px',width:'40px',borderRadius:'10px',margin:'10px',padding:'10px'}}>Edit</button>
          </div>
        ))}
      </div>
    </>
  );
};

export default Products;

