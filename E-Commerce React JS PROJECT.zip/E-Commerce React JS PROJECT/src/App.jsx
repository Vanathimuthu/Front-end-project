// import { useState } from 'react'
import Login from './page/Login.jsx';
import Register from './page/Register.jsx';
import './App.css'
import Design from './page/Designs/Design.jsx'
import Products from './page/Products.jsx';
import User from './page/User.jsx';
import Cart from './page/cart.jsx';
import {Routes,Route} from 'react-router-dom';
import Auth from './page/Authentication/Auth.jsx';
import Accessauth from './page/Authentication/Accessauth.jsx';
import ProductDescription from './page/ProductDescription.jsx';
import Home from './page/Designs/layout/headerpages/Home.jsx';
import Brandname from './page/Designs/layout/headerpages/Brandname.jsx'
import Userprofile from './page/Designs/layout/headerpages/Userprofile.jsx';
import Logout from './page/Designs/layout/headerpages/Logout.jsx'

function App() {
 
  return (
  
      <Routes>
        <Route path='/' element={<Register/>} />
        <Route path='/login' element={<Login/>} />
        <Route path='/register' element={<Register/>} />

        <Route element={< Auth/>}>
         <Route element={<Design/>}>

        <Route element={<Accessauth allowedaccess={["admin","users"]} />}>
        {/* <Route element={<Design/>} > */}
          <Route path='/products' element={<Products  />}/>
          <Route path='/cart' element={<Cart/>}/>
          <Route path='/product/:id' element={<ProductDescription/>} />
          <Route path='/home' element={<Home/>} />
          <Route path='/brandname' element={<Brandname/>} />
          <Route path='/userprofile' element={<Userprofile/>} />
          <Route path='/logout' element={<Logout/>} />
        </Route>
             <Route element={<Accessauth allowedaccess={["admin"]}/>}>
                 <Route path='/user' element={<User/>}/>
             </Route>
             </Route>
           
        </Route>
      </Routes>
        
   
  );
}

export default App;
